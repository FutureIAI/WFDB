import os
import cv2
import numpy as np
import re
import shutil


def extract_base_sequence_number(filename):
    """
    提取样本的基准时序序号（核心函数）
    - 原始样本 sample_0005.png → 5
    - 增强样本 aug_0001_sample_0005.png → 5（绑定原始样本序号）
    """
    # 匹配增强样本（优先提取原始样本序号）
    aug_pattern = re.compile(r'aug_\d+_sample_(\d+)\.png', re.IGNORECASE)
    aug_match = aug_pattern.search(filename)
    if aug_match:
        return int(aug_match.group(1))

    # 匹配原始样本
    sample_pattern = re.compile(r'sample_(\d+)\.png', re.IGNORECASE)
    sample_match = sample_pattern.search(filename)
    if sample_match:
        return int(sample_match.group(1))

    # 其他格式（按文件名数字兜底，确保不报错）
    numbers = re.findall(r'\d+', filename)
    return int(numbers[0]) if numbers else 0


def get_ordered_samples(subclass_dir):
    """
    按时序排序样本路径（原始样本在前，增强样本紧随其后）
    """
    # 获取所有图像文件
    img_extensions = ('.png', '.jpg')
    all_files = [f for f in os.listdir(subclass_dir) if f.lower().endswith(img_extensions)]

    # 为每个文件生成排序键：(基准序号, 是否增强样本, 增强序号)
    # 排序逻辑：基准序号升序 → 原始样本（0）在增强样本（1）前 → 增强序号升序
    def sort_key(filename):
        base_num = extract_base_sequence_number(filename)
        # 判断是否为增强样本
        is_aug = 1 if 'aug' in filename.lower() else 0
        # 提取增强序号（用于增强样本内部排序）
        if is_aug:
            aug_num = int(re.findall(r'aug_(\d+)_', filename)[0])
        else:
            aug_num = 0
        return (base_num, is_aug, aug_num)

    # 按自定义键排序
    sorted_files = sorted(all_files, key=sort_key)
    # 返回完整路径
    return [os.path.join(subclass_dir, f) for f in sorted_files]


def build_3d_samples(
        input_2d_dir,
        output_3d_dir,
        seq_length=10,
        overlap_ratio=0.5
):
    """
    构建3DCNN样本（保证时序关联，文件名不以数字开头）
    :param seq_length: 3D样本的时序长度（如10）
    :param overlap_ratio: 滑动窗口重叠率（0.5即50%）
    """
    os.makedirs(output_3d_dir, exist_ok=True)
    step = int(seq_length * (1 - overlap_ratio))  # 滑动步长
    if step < 1:
        step = 1  # 确保步长至少为1

    # 遍历所有子类别
    for subclass in os.listdir(input_2d_dir):
        subclass_2d_path = os.path.join(input_2d_dir, subclass)
        if not os.path.isdir(subclass_2d_path):
            continue

        # 1. 按时序排序该子类别的所有样本
        ordered_paths = get_ordered_samples(subclass_2d_path)
        total_samples = len(ordered_paths)
        if total_samples < seq_length:
            print(f"子类别 {subclass} 样本不足（{total_samples} < {seq_length}），跳过")
            continue
        print(f"处理子类别 {subclass}：{total_samples} 个样本（已时序排序）")

        # 2. 创建3D样本保存目录
        subclass_3d_path = os.path.join(output_3d_dir, subclass)
        os.makedirs(subclass_3d_path, exist_ok=True)

        # 3. 滑动窗口生成3D样本
        sample_count = 0
        for i in range(0, total_samples - seq_length + 1, step):
            # 提取连续seq_length个样本
            window_paths = ordered_paths[i:i + seq_length]
            window_images = []
            valid_window = True

            for img_path in window_paths:
                img = cv2.imread(img_path)
                if img is None:
                    valid_window = False
                    break
                # 转为RGB并归一化到[0,1]
                img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                window_images.append(img_rgb / 255.0)

            if not valid_window:
                continue

            # 堆叠为3D样本（shape: [seq_length, height, width, 3]）
            sample_3d = np.stack(window_images, axis=0)

            # 4. 保存3D样本（文件名不以数字开头，含时序范围）
            # 提取窗口内第一个和最后一个样本的基准序号
            first_base = extract_base_sequence_number(os.path.basename(window_paths[0]))
            last_base = extract_base_sequence_number(os.path.basename(window_paths[-1]))
            # 文件名格式：seq_<序号>_range_<起始>-<结束>.npz
            save_name = f"seq_{sample_count:04d}_range_{first_base}-{last_base}.npz"
            save_path = os.path.join(subclass_3d_path, save_name)

            np.savez_compressed(
                save_path,
                data=sample_3d,
                subclass=subclass,
                start_idx=first_base,
                end_idx=last_base
            )

            sample_count += 1

        print(f"  生成 {sample_count} 个3D样本（时序长度 {seq_length}）")


# 执行3D样本构建
if __name__ == "__main__":
    build_3d_samples(
        input_2d_dir="cwrud_balanced_dataset",  # 输入平衡后的2D数据集目录
        output_3d_dir="3d_cnn_dataset",  # 输出3D样本目录
        seq_length=8,  # 时序长度（根据需求调整）
        overlap_ratio=0.5  # 重叠率
    )