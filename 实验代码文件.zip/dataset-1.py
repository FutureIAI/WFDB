import numpy as np
import scipy.io as sio
from scipy import signal
import scipy
import pywt
from scipy import interpolate  # 单独导入interpolate模块
import cv2
import matplotlib.pyplot as plt
import os
import pickle


def load_cwru_de_data(file_path, fs=12000):
    """
    仅加载CWRU轴承数据的【驱动端信号（DE）】
    :param file_path: .mat文件路径（如"CWRU_data/12kHz/IR_0.007_1hp.mat"）
    :param fs: 采样频率（12kHz/48kHz，需与文件实际采样率匹配）
    :return:
        - de_sig_1d: 驱动端1D时序信号
        - label: 故障标签（如"IR_0.007_1hp"）
    """
    # 1. 读取.mat文件
    mat_data = sio.loadmat(file_path)

    # 2. 定位驱动端信号键（匹配包含"DE_time"的键，如"X105_DE_time"）
    de_key = [k for k in mat_data.keys() if "DE_time" in k][0]

    # 3. 提取驱动端信号并转为1D数组（原始为n×1二维数组）
    de_sig_2d = mat_data[de_key]
    de_sig_1d = de_sig_2d.flatten()

    # 4. 从文件名提取故障标签
    file_name = os.path.splitext(os.path.basename(file_path))[0]
    label = file_name

    return de_sig_1d, label, fs  # 移除rpm返回值


# 示例：加载单个文件的驱动端信号
file_path = "CWRU/inner/IR007_0.mat"
de_sig, cwru_label, fs = load_cwru_de_data(file_path, fs=12000)
print(f"驱动端信号长度：{len(de_sig)}, 故障标签：{cwru_label},原始数据:{de_sig}")


def wavelet_denoise(raw_sig, wavelet='db4', level=3):
    """小波去噪（保留驱动端信号的冲击故障特征）"""
    # 小波分解
    coeffs = pywt.wavedec(raw_sig, wavelet, level=level)
    # 估计噪声标准差（通用阈值法）
    sigma = np.median(np.abs(coeffs[-1])) / 0.6745
    threshold = sigma * np.sqrt(2 * np.log(len(raw_sig)))
    # 软阈值处理高频系数（保留冲击特征）
    coeffs[1:] = [pywt.threshold(c, threshold, mode='soft') for c in coeffs[1:]]
    # 重构信号并保持长度一致
    denoised_sig = pywt.waverec(coeffs, wavelet)
    return denoised_sig[:len(raw_sig)]


def preprocess_de_signal(raw_sig, target_len=1024):
    """驱动端信号预处理：去噪→长度统一→归一化"""
    # 1. 小波去噪（抑制高频噪声，保留故障冲击）
    denoised_sig = wavelet_denoise(raw_sig)

    # 2. 线性插值统一长度（修正：使用interpolate模块）
    if len(denoised_sig) != target_len:
        t_old = np.linspace(0, 1, len(denoised_sig))
        t_new = np.linspace(0, 1, target_len)
        # 核心修正：signal.interpolate.interp1d → interpolate.interp1d
        interp_func = interpolate.interp1d(t_old, denoised_sig, kind='linear')
        resampled_sig = interp_func(t_new)
    else:
        resampled_sig = denoised_sig

    # 3. 样本内归一化（消除不同负载的幅值差异）
    normalized_sig = (resampled_sig - resampled_sig.min()) / (resampled_sig.max() - resampled_sig.min())
    return normalized_sig


# 示例：预处理驱动端信号（目标尺寸32×32=1024）
##target_len = 32 * 32
##processed_de_sig = preprocess_de_signal(de_sig, target_len=target_len)
##print(f"预处理后驱动端信号长度：{len(processed_de_sig)},预处理后驱动端信号:{processed_de_sig}")

def build_R_channel(processed_sig, H=32, W=32):
    """R通道：驱动端时域信号→2D映射"""
    # 1D→2D（行优先映射，确保三通道对齐）
    R = processed_sig.reshape((H, W), order='C')
    # 转为0-255的图像格式
    R = (R * 255).astype(np.uint8)
    return R

# 示例构建R通道
##H, W = 32, 32
##R_channel = build_R_channel(processed_de_sig, H=H, W=W)
##print(f"R通道（时域）尺寸：{R_channel.shape}")


def build_G_channel(processed_sig, fs=12000, H=32, W=32):
    """G通道：驱动端FFT频域→2D映射"""
    # 1. 计算FFT幅度谱（仅保留正频率部分：0~fs/2）
    sig_len = len(processed_sig)
    fft_result = np.fft.fft(processed_sig)
    fft_mag = np.abs(fft_result)[:sig_len // 2 + 1]

    # 2. 插值到H×W尺寸（修正：使用interpolate模块）
    t_old = np.linspace(0, 1, len(fft_mag))
    t_new = np.linspace(0, 1, H * W)
    # 核心修正：signal.interpolate.interp1d → interpolate.interp1d
    fft_mag_interp = interpolate.interp1d(t_old, fft_mag, kind='linear')(t_new)

    # 3. 对数压缩（避免直流分量掩盖故障频率）
    fft_mag_log = np.log1p(fft_mag_interp)  # log(1+x)防止log(0)
    # 归一化到0-255
    fft_norm = (fft_mag_log - fft_mag_log.min()) / (fft_mag_log.max() - fft_mag_log.min())
    G = (fft_norm * 255).astype(np.uint8).reshape((H, W), order='C')
    return G


# 示例构建G通道
##G_channel = build_G_channel(processed_de_sig, fs=fs, H=H, W=W)
##print(f"G通道（频域）尺寸：{G_channel.shape}")


def build_B_channel(processed_sig, fs=12000, H=32, W=32):
    """B通道：驱动端STFT时频域→2D映射（修复插值函数过时警告）"""
    import scipy.signal as sig
    from scipy.interpolate import RegularGridInterpolator  # 导入官方推荐的新插值函数

    # 1. STFT参数设置
    nperseg = 64  # 窗长
    noverlap = 32  # 50%重叠率

    # 2. 生成hann窗函数
    window = sig.get_window('hann', nperseg)

    # 3. 计算STFT
    f_stft, t_stft, Zxx = sig.stft(
        x=processed_sig,
        fs=fs,
        window=window,
        nperseg=nperseg,
        noverlap=noverlap,
        boundary=None
    )
    stft_mag = np.abs(Zxx).T  # 形状：(时间窗数, 频率点)

    # 4. 用RegularGridInterpolator替代interp2d（核心修改）
    # 原始网格坐标（归一化到0-1范围）
    t_coords = np.linspace(0, 1, stft_mag.shape[0])  # 时间维度坐标
    f_coords = np.linspace(0, 1, stft_mag.shape[1])  # 频率维度坐标

    # 创建插值函数
    interp_func = RegularGridInterpolator(
        (t_coords, f_coords),  # 网格坐标（先时间后频率）
        stft_mag,  # 待插值的数据
        method='linear',  # 线性插值（与原逻辑一致）
        bounds_error=False,  # 超出边界不报错
        fill_value=0  # 边界外填充0
    )

    # 生成目标网格点
    t_new = np.linspace(0, 1, H)
    f_new = np.linspace(0, 1, W)
    t_grid, f_grid = np.meshgrid(t_new, f_new, indexing='ij')  # 生成H×W的网格
    points = np.stack([t_grid, f_grid], axis=-1)  # 形状：(H, W, 2)

    # 执行插值
    stft_interp = interp_func(points)

    # 5. 对数压缩与归一化
    stft_mag_log = np.log1p(stft_interp)
    stft_norm = (stft_mag_log - stft_mag_log.min()) / (stft_mag_log.max() - stft_mag_log.min())
    B_channel = (stft_norm * 255).astype(np.uint8)

    return B_channel


# 示例构建B通道
##B_channel = build_B_channel(processed_de_sig, fs=fs, H=H, W=W)
##print(f"B通道（时频域）尺寸：{B_channel.shape}")
def verify_alignment(R, G, B, H=32, W=32):
    """验证三通道尺寸是否一致（驱动端信号专用）"""
    assert R.shape == G.shape == B.shape == (H, W), f"三通道尺寸不匹配！R:{R.shape}, G:{G.shape}, B:{B.shape}"
    print("✅ 驱动端信号三通道对齐验证通过！")

def fuse_rgb(de_R, de_G, de_B, save_path=None):
    """融合驱动端三通道为RGB图像并保存"""
    # 堆叠为RGB格式（Matplotlib显示顺序）
    rgb_image = np.stack([de_R, de_G, de_B], axis=-1)
    # 保存时转换为OpenCV的BGR格式（避免颜色反转）
    if save_path is not None:
        # 确保保存目录存在
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        bgr_image = cv2.cvtColor(rgb_image, cv2.COLOR_RGB2BGR)
        cv2.imwrite(save_path, bgr_image)
    return rgb_image

# 1. 对齐验证
##verify_alignment(R_channel, G_channel, B_channel, H=H, W=W)

# 2. 融合并保存RGB图像
##save_path = f"cwru_de_rgb/{cwru_label}/sample_001.png"
##rgb_image = fuse_rgb(R_channel, G_channel, B_channel, save_path=save_path)
##print(f"驱动端RGB图像尺寸：{rgb_image.shape}")

# 3. 可视化驱动端信号的三通道特征
# 添加中文显示配置（核心修复）
##plt.rcParams["font.family"] = ["SimHei", "Microsoft YaHei"]  # 适配不同系统的中文字体
##plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题

##plt.figure(figsize=(12, 3))
##plt.subplot(141); plt.imshow(R_channel, cmap='gray'); plt.title("R: 驱动端时域（冲击）")
##plt.subplot(142); plt.imshow(G_channel, cmap='gray'); plt.title("G: 驱动端频域（特征频率）")
##plt.subplot(143); plt.imshow(B_channel, cmap='gray'); plt.title("B: 驱动端时频域（冲击时序）")
##plt.subplot(144); plt.imshow(rgb_image); plt.title("RGB融合（故障特征融合）")
##plt.tight_layout(); plt.show()


def split_de_signal_to_samples(de_sig, sample_len=1024, overlap_rate=0.5):
    """将长驱动端信号分割为多个样本（支持重叠，增加样本量）"""
    step = int(sample_len * (1 - overlap_rate))
    # 按步长分割，确保每个样本长度为sample_len
    samples = [
        de_sig[i:i + sample_len]
        for i in range(0, len(de_sig) - sample_len + 1, step)
    ]
    return samples

"""
def batch_process_de_signals(root_folder, fs=12000, H=32, W=32, save_root="cwru_de_rgb_dataset"):
    #批量处理所有.mat文件的驱动端信号，生成RGB图像数据集
    # 遍历根目录下所有.mat文件（支持子文件夹递归）
    for root, _, files in os.walk(root_folder):
        for file in files:
            if file.endswith(".mat"):
                file_path = os.path.join(root, file)
                print(f"正在处理驱动端信号：{file_path}")

                # 1. 加载驱动端信号（无转速）
                de_sig, label, _ = load_cwru_de_data(file_path, fs=fs)

                # 2. 将长信号分割为多个样本（50%重叠率，增加样本多样性）
                sample_len = H * W
                de_samples = split_de_signal_to_samples(de_sig, sample_len=sample_len, overlap_rate=0.5)
                print(f"  驱动端信号分割为 {len(de_samples)} 个样本")

                # 3. 逐个样本生成RGB图像
                for idx, sample in enumerate(de_samples):
                    # 预处理
                    processed_sample = preprocess_de_signal(sample, target_len=sample_len)
                    # 构建三通道
                    R = build_R_channel(processed_sample, H=H, W=W)
                    G = build_G_channel(processed_sample, fs=fs, H=H, W=W)
                    B = build_B_channel(processed_sample, fs=fs, H=H, W=W)
                    # 保存（按故障标签分类存储）
                    save_path = os.path.join(save_root, label, f"sample_{idx:04d}.png")
                    fuse_rgb(R, G, B, save_path=save_path)

                print(f"  ✅ {file} 驱动端信号处理完成\n")


# 示例：批量处理CWRU所有数据的驱动端信号
batch_process_de_signals(
    root_folder="CWRU",  # 数据集根目录（含12kHz/48kHz子文件夹）
    fs=12000,
    H=32,
    W=32,
    save_root="cwru_de_RGB_dataset_12k_007"
)
"""


def batch_process_de_signals_with_signal_save(root_folder, fs=12000, H=32, W=32,
                                              save_root="cwru_de_rgb_dataset",
                                              signal_map_path="signal_image_map.pkl"):
    """批量生成RGB图像，并保存信号-图像路径映射关系"""
    signal_image_map = {}  # 键：图像路径，值：对应的预处理信号

    for root, _, files in os.walk(root_folder):
        for file in files:
            if file.endswith(".mat"):
                file_path = os.path.join(root, file)
                de_sig, label, _ = load_cwru_de_data(file_path, fs=fs)
                sample_len = H * W
                de_samples = split_de_signal_to_samples(de_sig, sample_len=sample_len, overlap_rate=0.5)

                for idx, sample in enumerate(de_samples):
                    processed_sample = preprocess_de_signal(sample, target_len=sample_len)
                    R = build_R_channel(processed_sample, H=H, W=W)
                    G = build_G_channel(processed_sample, fs=fs, H=H, W=W)
                    B = build_B_channel(processed_sample, fs=fs, H=H, W=W)

                    # 保存RGB图像
                    save_path = os.path.join(save_root, label, f"sample_{idx:04d}.png")
                    fuse_rgb(R, G, B, save_path=save_path)

                    # 记录信号-图像映射
                    signal_image_map[save_path] = processed_sample  # 存储预处理后的1D信号

    # 保存映射关系到文件（后续筛选用）
    with open(signal_map_path, "wb") as f:
        pickle.dump(signal_image_map, f)
    print(f"信号-图像映射已保存至 {signal_map_path}，共 {len(signal_image_map)} 条记录")


# 执行批量生成（若已生成RGB，可单独运行此函数补录映射）
batch_process_de_signals_with_signal_save(
    root_folder="CWRU",
    save_root="cwru_de_rgb_dataset_signal",
    signal_map_path="signal_image_map.pkl"
)