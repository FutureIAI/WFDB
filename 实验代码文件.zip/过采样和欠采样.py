import os
import cv2
import numpy as np
import random
import shutil


def oversample_fault_minor_classes(raw_fault_dir, save_fault_dir, target_count=150):
    """
    过采样故障小类别至目标数量（保留故障特征）
    :param raw_fault_dir: 原始故障样本目录（含各子类别）
    :param save_fault_dir: 过采样后保存目录
    :param target_count: 每个子类别目标样本数
    """
    os.makedirs(save_fault_dir, exist_ok=True)

    # 遍历所有故障子类别（排除正常样本）
    for subclass in os.listdir(raw_fault_dir):
        subclass_path = os.path.join(raw_fault_dir, subclass)
        if not os.path.isdir(subclass_path) or "normal" in subclass.lower():
            continue

        # 获取该子类别所有样本路径
        img_names = [f for f in os.listdir(subclass_path) if f.endswith((".png", ".jpg"))]
        img_paths = [os.path.join(subclass_path, f) for f in img_names]
        current_count = len(img_paths)
        print(f"处理故障子类别 {subclass}：原始{current_count}张 → 目标{target_count}张")

        # 创建保存目录
        save_subclass_dir = os.path.join(save_fault_dir, subclass)
        os.makedirs(save_subclass_dir, exist_ok=True)

        # 1. 复制原始样本（保留真实特征）
        for img_path in img_paths:
            shutil.copy(img_path, os.path.join(save_subclass_dir, os.path.basename(img_path)))

        # 2. 若需过采样，生成增强样本（控制变换幅度，防止特征丢失）
        if current_count >= target_count:
            continue
        need_count = target_count - current_count

        # 特征保留的增强函数（仅微小变换）
        def safe_augment(img):
            # a. 轻微旋转（±3°，边缘反射填充，不破坏冲击信号时序）
            rows, cols = img.shape[:2]
            angle = random.uniform(-3, 3)  # 限制旋转角度，避免特征变形
            M = cv2.getRotationMatrix2D((cols / 2, rows / 2), angle, 1)
            img_rot = cv2.warpAffine(img, M, (cols, rows), borderMode=cv2.BORDER_REFLECT)

            # b. 轻微亮度调整（±5%，不改变频域峰值相对强度）
            alpha = random.uniform(0.95, 1.05)  # 亮度因子接近1
            img_bright = np.clip(img_rot * alpha, 0, 255).astype(np.uint8)

            return img_bright

        # 生成增强样本（循环直至满足目标数量）
        for i in range(need_count):
            # 随机选择原始样本进行增强（保证多样性）
            src_img = cv2.imread(random.choice(img_paths))
            aug_img = safe_augment(src_img)

            # 保存增强样本（标记aug，区分原始样本）
            save_name = f"aug_{i:04d}_" + os.path.basename(random.choice(img_names))
            cv2.imwrite(os.path.join(save_subclass_dir, save_name), aug_img)

        print(f"  过采样完成：新增{need_count}张，共{target_count}张")


def undersample_normal_major_classes(raw_normal_dir, save_normal_dir, target_max=400):
    """
    欠采样正常大类别至目标数量（保留特征多样性）
    :param raw_normal_dir: 原始正常样本目录（含各子类别）
    :param save_normal_dir: 欠采样后保存目录
    :param target_max: 每个子类别最大样本数
    """
    os.makedirs(save_normal_dir, exist_ok=True)

    # 遍历所有正常子类别
    for subclass in os.listdir(raw_normal_dir):
        subclass_path = os.path.join(raw_normal_dir, subclass)
        if not os.path.isdir(subclass_path) or "normal" not in subclass.lower():
            continue

        # 获取该子类别所有样本路径（按文件名排序，确保时序性）
        img_names = sorted([f for f in os.listdir(subclass_path) if f.endswith((".png", ".jpg"))],
                           key=lambda x: int(x.split("_")[1].split(".")[0]))  # 按样本序号排序
        img_paths = [os.path.join(subclass_path, f) for f in img_names]
        current_count = len(img_paths)
        print(f"处理正常子类别 {subclass}：原始{current_count}张 → 目标≤{target_max}张")

        # 创建保存目录
        save_subclass_dir = os.path.join(save_normal_dir, subclass)
        os.makedirs(save_subclass_dir, exist_ok=True)

        # 1. 若无需欠采样，直接复制所有样本
        if current_count <= target_max:
            for img_path in img_paths:
                shutil.copy(img_path, os.path.join(save_subclass_dir, os.path.basename(img_path)))
            continue

        # 2. 需欠采样：分层随机抽样（保留各时间段特征）
        # 按10段分层，每段按比例保留样本
        num_segments = 10
        segment_size = current_count // num_segments
        selected = []

        for i in range(num_segments):
            # 确定当前段的样本范围
            start = i * segment_size
            end = start + segment_size if i < num_segments - 1 else current_count
            segment = img_paths[start:end]

            # 按比例计算该段需保留的样本数
            segment_ratio = len(segment) / current_count
            segment_target = int(segment_ratio * target_max) + 1  # +1避免0样本
            segment_target = min(segment_target, len(segment))  # 不超过段内样本数

            # 随机选择该段的样本（保留时间段多样性）
            selected += random.sample(segment, segment_target)

        # 若总数量超过目标，再随机删除多余样本（确保不超过target_max）
        if len(selected) > target_max:
            selected = random.sample(selected, target_max)

        # 保存选中的样本
        for img_path in selected:
            shutil.copy(img_path, os.path.join(save_subclass_dir, os.path.basename(img_path)))

        print(f"  欠采样完成：保留{len(selected)}张，删除{current_count - len(selected)}张")


def merge_balanced_dataset(oversampled_fault_dir, undersampled_normal_dir, final_dataset_dir):
    """整合过采样的故障样本和欠采样的正常样本，输出最终分布"""
    os.makedirs(final_dataset_dir, exist_ok=True)

    # 1. 复制过采样后的故障样本
    for subclass in os.listdir(oversampled_fault_dir):
        src_dir = os.path.join(oversampled_fault_dir, subclass)
        dst_dir = os.path.join(final_dataset_dir, subclass)
        shutil.copytree(src_dir, dst_dir, dirs_exist_ok=True)

    # 2. 复制欠采样后的正常样本
    for subclass in os.listdir(undersampled_normal_dir):
        src_dir = os.path.join(undersampled_normal_dir, subclass)
        dst_dir = os.path.join(final_dataset_dir, subclass)
        shutil.copytree(src_dir, dst_dir, dirs_exist_ok=True)

    # 3. 输出最终数据集分布
    print("\n===== 最终平衡数据集分布 =====")
    total_normal = 0
    total_fault = 0

    # 统计正常样本
    print("正常样本：")
    for subclass in os.listdir(final_dataset_dir):
        if "normal" in subclass.lower():
            cnt = len(os.listdir(os.path.join(final_dataset_dir, subclass)))
            total_normal += cnt
            print(f"  {subclass}: {cnt}张")

    # 统计故障样本
    print("\n故障样本：")
    for subclass in os.listdir(final_dataset_dir):
        if "normal" not in subclass.lower():
            cnt = len(os.listdir(os.path.join(final_dataset_dir, subclass)))
            total_fault += cnt
            print(f"  {subclass}: {cnt}张")

    print(f"\n总计：正常{total_normal}张，故障{total_fault}张，比例{total_normal / total_fault:.2f}:1")


# 过采样故障小类别（目标150张/类）
oversample_fault_minor_classes(
    raw_fault_dir="filtered_rgb_dataset",  # 筛选后的故障样本根目录
    save_fault_dir="oversampled_faults",
    target_count=150
)

# 欠采样正常大类别（目标≤400张/类）
undersample_normal_major_classes(
    raw_normal_dir="filtered_rgb_dataset",  # 筛选后的正常样本根目录
    save_normal_dir="undersampled_normals",
    target_max=400
)

# 整合为最终标准数据集
merge_balanced_dataset(
    oversampled_fault_dir="oversampled_faults",
    undersampled_normal_dir="undersampled_normals",
    final_dataset_dir="cwrud_balanced_dataset"
)