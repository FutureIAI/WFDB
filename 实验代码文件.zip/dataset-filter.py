import os
import pickle

import cv2
import numpy as np
from scipy.stats import kurtosis
from tqdm import tqdm

def calculate_image_entropy(image):
    """计算图像信息熵（反映特征丰富度）"""
    hist = cv2.calcHist([image], [0], None, [256], [0, 256])
    hist = hist / hist.sum()
    return -np.sum(hist * np.log2(hist + 1e-10))
def calculate_snr_optimized(signal, is_fault=False):
    """优化SNR计算：动态选择噪声段（故障样本避免固定前100点）"""
    # 对故障样本：找信号中最平稳的100点作为噪声段（而非固定前100点）
    if is_fault:
        # 计算滑动窗口方差（窗口大小50），找方差最小的100点
        window_size = 50
        variances = [np.var(signal[i:i + window_size]) for i in range(len(signal) - window_size)]
        min_var_idx = np.argmin(variances)
        noise = signal[min_var_idx: min_var_idx + 100]  # 最平稳段作为噪声
    else:
        # 正常样本仍用前100点作为噪声段
        noise = signal[:100] if len(signal) >= 100 else signal

    signal_part = signal[100:] if len(signal) >= 100 else signal
    p_noise = np.var(noise)
    p_signal = np.var(signal_part)
    return 10 * np.log10(p_signal / p_noise) if p_noise != 0 else 100


def filter_with_adjusted_thresholds(signal_map_path, raw_rgb_root, filtered_root):
    """分类型调整阈值的筛选函数（故障样本宽松，正常样本严格）"""
    with open(signal_map_path, "rb") as f:
        signal_map = pickle.load(f)

    os.makedirs(filtered_root, exist_ok=True)
    valid_count = 0
    fault_labels = [label for label in os.listdir(raw_rgb_root) if "normal" not in label.lower()]

    for img_path in tqdm(signal_map.keys(), desc="宽松筛选样本"):
        processed_signal = signal_map[img_path]
        label = os.path.basename(os.path.dirname(img_path))
        is_fault = label in fault_labels  # 判断是否为故障样本

        # 1. 信号指标（分类型阈值）
        snr = calculate_snr_optimized(processed_signal, is_fault=is_fault)
        snr_thresh = 2 if is_fault else 5  # 故障样本SNR≥2dB，正常≥5dB

        signal_var = np.var(processed_signal)
        var_thresh = 0.005 if is_fault else 0.01  # 故障样本方差≥0.005

        if snr < snr_thresh or signal_var < var_thresh:
            continue

        # 2. 图像指标（分类型阈值）
        img = cv2.imread(img_path)
        if img is None:
            continue
        r_channel = img[:, :, 2]
        g_channel = img[:, :, 1]

        r_entropy = calculate_image_entropy(r_channel)
        entropy_thresh = 2.5 if is_fault else 3  # 故障样本熵≥2.5
        if r_entropy < entropy_thresh:
            continue

        # 3. 故障样本频域峰度（放宽至1.5）
        if is_fault:
            g_kurt = kurtosis(g_channel.flatten())
            if g_kurt < 1.5:  # 原阈值2→1.5
                continue

        # 保存合格样本
        save_dir = os.path.join(filtered_root, label)
        os.makedirs(save_dir, exist_ok=True)
        cv2.imwrite(os.path.join(save_dir, os.path.basename(img_path)), img)
        valid_count += 1

    print(f"宽松筛选完成：共保留 {valid_count} 个样本")
    for label in os.listdir(filtered_root):
        print(f"  {label}: {len(os.listdir(os.path.join(filtered_root, label)))} 张")

"""
# 执行宽松筛选（覆盖原筛选结果）
filter_with_adjusted_thresholds(
    signal_map_path="signal_image_map.pkl",
    raw_rgb_root="cwru_de_rgb_dataset_signal",
    filtered_root="filtered_rgb_dataset"  # 覆盖原目录
)
"""


def is_normal_sample_valid(signal, img_path, fs=12000):
    """添加日志的调试版：输出被触发的排除条件"""
    # 1. 信号标准差检查
    sig_std = np.std(signal)
    if sig_std < 0.001 or sig_std > 0.5:
        print(f"排除：标准差={sig_std:.4f}（不在0.001-0.5）")  # 新增日志
        return False

    # 2. 滑动窗口方差波动检查
    window_size = 100
    windows = [signal[i:i + window_size] for i in range(0, len(signal) - window_size, window_size)]
    if not windows:  # 避免窗口为空
        print("排除：信号过短，无法生成窗口")
        return False
    window_vars = [np.var(w) for w in windows]
    var_cv = np.std(window_vars) / np.mean(window_vars)
    if var_cv > 0.7:
        print(f"排除：变异系数={var_cv:.4f}（>0.3=7）")  # 新增日志
        return False

    # 3. 频域峰度检查
    img = cv2.imread(img_path)
    if img is None:
        print("排除：图像无法读取")
        return False
    g_channel = img[:, :, 1]
    g_kurt = kurtosis(g_channel.flatten())
    if g_kurt > 4.5:
        print(f"排除：频域峰度={g_kurt:.4f}（>4.5）")  # 新增日志
        return False

    # 4. 时频域局部能量检查
    b_channel = img[:, :, 0]
    b_max = np.max(b_channel)
    b_mean = np.mean(b_channel)
    if b_max / (b_mean + 1e-10) > 21:
        print(f"排除：时频域能量比={b_max / b_mean:.4f}（>21）")  # 新增日志
        return False

    return True


def rescreen_normal_samples(raw_normal_dir, signal_map, save_normal_dir):
    """
    重新筛选正常样本（仅保留平稳无异常的样本）
    :param raw_normal_dir: 原始正常样本目录（如cwru_de_rgb_dataset/normal_0）
    :param signal_map: 信号-图像映射字典
    :param save_normal_dir: 筛选后正常样本保存目录
    """
    os.makedirs(save_normal_dir, exist_ok=True)
    valid_count = 0

    # 遍历所有原始正常样本（包括normal_0/1/2/3）
    for label in os.listdir(raw_normal_dir):
        if "normal" not in label.lower():
            continue
        label_dir = os.path.join(raw_normal_dir, label)
        img_paths = [os.path.join(label_dir, f) for f in os.listdir(label_dir) if f.endswith(".png")]

        for img_path in tqdm(img_paths, desc=f"重新筛选{label}"):
            if img_path not in signal_map:
                continue
            signal = signal_map[img_path]
            # 用正常样本专属逻辑判断
            if is_normal_sample_valid(signal, img_path):
                # 保存有效样本
                save_label_dir = os.path.join(save_normal_dir, label)
                os.makedirs(save_label_dir, exist_ok=True)
                img = cv2.imread(img_path)
                cv2.imwrite(os.path.join(save_label_dir, os.path.basename(img_path)), img)
                valid_count += 1

    print(f"正常样本重新筛选完成：共保留 {valid_count} 张")
    for label in os.listdir(save_normal_dir):
        print(f"  {label}: {len(os.listdir(os.path.join(save_normal_dir, label)))} 张")
    return valid_count


# 执行正常样本重新筛选
# 1. 加载信号-图像映射
with open("signal_image_map.pkl", "rb") as f:
    signal_map = pickle.load(f)

# 2. 重新筛选（原始正常样本目录=原RGB数据集的normal目录）
rescreen_normal_samples(
    raw_normal_dir="cwru_de_rgb_dataset_signal",  # 原始RGB数据集根目录（含normal_0/1/2/3）
    signal_map=signal_map,
    save_normal_dir="filtered_rgb_dataset"  # 单独保存筛选后的正常样本
)